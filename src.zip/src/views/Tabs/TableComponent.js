
import React, {Component, PureComponent } from "react";
import EventEmitter from "react-native-eventemitter"; 
import _ from 'lodash';
import { Container,Alert,Nav,NavItem,FormGroup,Label,Table, Badge,Row,Col,Card,CardHeader,FormText,CardBlock,Button,Modal, ModalHeader, ModalBody, ModalFooter,Input, InputGroup, InputGroupAddon } from "reactstrap";
 

 class TableComponent extends  React.Component{
    constructor(props) {
        super(props);
     console.log(this.props.rows);
       this.state={
           showInput:false
       }
     console.log(props);
    this.editUser = this.editUser.bind(this);

    }
    editUser(item){
        console.log(item);
        this.setState({
            showInput: true
        })
    } 
   render() {
  
    return (
         <div>
      <Table>
        <thead>
          <tr>
              { this.props.columNames.map((item, index) => (
                   <th>{item.title}</th>
                ))}
          </tr>
        </thead>
        <tbody>
          { this.props.rows.map((item, index) => (

          <tr key={index}>
             <th>{index}</th>
          { item.cells.map((item1, index1) => (   
              this.state.showInput == false ? <td key={index1}>{item1}</td>: <input type="text" value={item1} />
           ))}
           <td onClick={this.editUser.bind(this,item)}>Edit</td>
          </tr>
          ))}
        </tbody>
      </Table>
     </div>
    );

        
}
}

export default TableComponent